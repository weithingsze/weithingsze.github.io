# Your website — how it works, and how to keep it working

Read the first section even if you skip the rest. It explains a problem that has
been silently breaking your edits.

---

## 1. The thing that has been going wrong

When you download a file that already exists in your Downloads folder, your
browser does not overwrite it — it saves a second copy with a number:

```
data.js
data (1).js
data (2).js
```

Those numbered copies then got uploaded to GitHub alongside the original. Your
repository currently holds:

```
data.js          ← the site loads THIS one, and it is an old version
data (1).js
data (2).js
data (3).js
data (4).js
index.html
index (2).html
index (3).html
style.css
style (1).css
```

The site only ever reads `data.js`, `index.html` and `style.css` — the plain
names, no number. The numbered files are dead weight that nothing reads. So
every time a new version landed as `data (3).js`, the site kept showing the old
content, which is why your corrections "weren't showing".

**The fix is in section 2. Do it once and the problem is gone.**

To stop it happening again: before you download from here, delete the old copy
from your Downloads folder first. Or check the filename after downloading — if
it has `(1)` in it, rename it to the plain name before uploading.

---

## 2. One-time clean-up of your repository

Go to <https://github.com/weithingsze/weithingsze.github.io>

### Step A — delete the numbered duplicates

For each of these files:

- `data (1).js`
- `data (2).js`
- `data (3).js`
- `data (4).js`
- `index (2).html`
- `index (3).html`
- `style (1).css`

do this: click the filename → click the **⋯** menu at the top right of the file
view → **Delete file** → scroll down → **Commit changes**.

Seven files, about two minutes.

### Step B — delete `README.md` from the repository

Same steps. It is currently public, Google has indexed it, and it ranks ahead of
your actual site. You are holding the only copy you need — this document.

### Step C — do NOT delete these

- `google230a60bca17a17ff.html` — this is your Google Search Console
  verification. Deleting it disconnects your site from Search Console.
- `CNAME`, if you ever add one.

### Step D — upload the clean set

1. On the repository page click **Add file** → **Upload files**
2. Open the `upload-to-github` folder from this package
3. Select all 15 files inside it and drag them into the browser
4. Scroll down, click **Commit changes**

Uploading a file that already exists replaces it. That is what you want here.

Wait 1–2 minutes, then open <https://weithingsze.github.io> and hard-refresh
(**Cmd+Shift+R** on Mac, **Ctrl+Shift+R** on Windows) — otherwise your browser
shows you its cached old copy and you will think nothing changed.

### Step E — check three things

- **Teaching & mentorship** → lectures say *Public Health Informatics, MPH*
- **Talks** → the DTx entry reads *The 2nd Academic Meeting, Digital Therapeutics
  Society, The University of Tokyo Hospital*, and conference presentations sit in
  a column beside invited talks
- **Cities** → Tokyo is a red dot, and hovering Gers says *Cultural exchange
  working holiday*
- **Teaching & mentorship** → a *Curriculum development* section sits between
  Courses and Lectures delivered, with the digital health design workshop in it

If all three look right, the repository is clean and current.

---

## 3. What goes on GitHub, and what never does

**Upload these 15 files** (everything in `upload-to-github`):

| File | What it is |
|---|---|
| `data.js` | **All your content.** The only file you normally edit |
| `render.js` | Turns your content into pages. Don't edit |
| `style.css` | Colours, fonts, spacing |
| `index.html` | Home |
| `bio.html` | Biography |
| `publications.html` | Publications |
| `talks.html` | Talks & presentations |
| `teaching.html` | Teaching & mentorship |
| `awards.html` | Milestones (the file keeps its old name — that's fine) |
| `community.html` | Community |
| `cities.html` | Cities, including the world map |
| `headshot.jpg` | Your portrait |
| `preview.png` | The image shown when your link is shared |
| `sitemap.xml` | Tells Google which pages exist |
| `robots.txt` | Tells crawlers they're welcome |

**Never upload these:**

- **`editor.html`** — it is in this package for you to use *on your own computer*.
  Anything in a public repository is visible to anyone, so keeping it out is what
  makes editing invisible to visitors.
- **`cv.pdf` or any CV file** — you said you don't want visitors downloading your
  CV. A file in a public repository can be downloaded by anyone who guesses the
  URL, whether or not a page links to it. And deleting it later does not help,
  because it stays in the commit history. Simply never put it there. Your CV
  lives on your computer and you send it to people yourself.
- **`HOW-TO-UPDATE.md`** — this document. It's for you.

---

## 4. Making a change

### The easy way — the editor

Keep `editor.html` in the same folder as `data.js` on your computer, and
double-click it. You get forms instead of code.

1. Pick a tab: Cities, Community, Talks, Lectures, Milestones, Publications,
   Courses, Education, Languages, Bio, or Contact & links
2. Fill in the form → **Add**
3. **Download data.js**
4. **Check the filename.** If it downloaded as `data (1).js`, rename it to
   `data.js`
5. Upload it to GitHub → Commit → hard-refresh your site

Cities are the nicest part: open the Cities tab and *click the map* where the
city is. The coordinates fill themselves in.

### The direct way — edit on GitHub

Open `data.js` on GitHub, click the pencil icon, and add a block to the right
list. A talk looks like this:

```js
{
  title: "Personalising dietary interventions with generative AI",
  event: "Japan Association for Medical Informatics Annual Conference",
  city: "Osaka, Japan",
  month: "Nov",
  year: 2026,
  kind: "conference",   // "conference" → left column; anything else → right column
},
```

A city looks like this:

```js
{ name: "Kyoto", country: "Japan", region: "Asia", lat: 35.01, lng: 135.77, note: "Conference" },
```

Same pattern for `lectures:`, `publications:`, `awards:`, `community:`.

The one thing that breaks a page is a missing comma. If a page goes blank after
an edit, open the repository, click **History**, open your last commit, and
revert it — nothing is ever lost.

### Ask here

For anything structural — a new page, layout, wording you want a second opinion
on — describe it and you'll get the changed files back.

---

## 5. Publications can update themselves

Your talks and lectures exist nowhere but your own records. Your publications
are indexed in public databases, so those can be automatic. In `data.js`:

```js
autoPublications: {
  enabled: true,
  orcidId: "0000-0003-1054-6886"
},
```

This is on. When the page loads it reads your ORCID record, finds anything not
already in your manual list, and fills in the author details from Crossref.

In practice: **whatever is in your ORCID record appears on your site.** If a
paper is missing from the page, add it to ORCID and it shows up — no editing
here at all.

Two caveats. Auto-added entries can't be flagged as first-author, because ORCID
doesn't record that. And Crossref author lists occasionally need tidying. If a
paper matters to you, copy it into the `publications` list in `data.js` and it
will be formatted exactly like the others. Your manual list always shows — the
ORCID check only ever *adds*.

---

## 6. Getting found on Google

The technical side is done: `sitemap.xml`, `robots.txt`, structured data, and
Search Console verification are all in place and live.

What's missing is links. Google finds pages mainly by following links from pages
it already trusts, and right now nothing on the internet points at your site.
Adding a few links is the single most effective thing you can do, and each takes
under a minute:

- **LinkedIn** — add the URL to your profile's Website field, and put it in your
  About section as plain text too
- **ORCID** — Websites & social links → add it
- **ResearchGate** — same
- **Your UTokyo staff page** — ask whoever maintains it to link your site
- **Your email signature** — every email becomes a small signal
- **Google Scholar** — add it to your profile's homepage field

Then in Search Console, open **URL Inspection**, paste
`https://weithingsze.github.io`, and click **Request indexing**. That asks Google
to look now rather than whenever it gets around to it. Do the same for
`/publications.html` and `/bio.html`.

Expect a few days to a couple of weeks. Searching your own name is a poor test
early on — search `site:weithingsze.github.io` instead, which shows exactly what
Google has indexed.

---

## 7. Previewing before you upload

Double-click `index.html` on your computer. The whole site works locally exactly
as it does live, because there is no build step. Click through every page you
changed before you upload anything.
